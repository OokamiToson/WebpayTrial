<?php
//Pagina de error xd
http_response_code(403);
die();
?>