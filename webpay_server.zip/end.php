<?php
//Este archivo no hace nada pero es necesario para que webpay funcione. Y la app movil tambien c:
?>