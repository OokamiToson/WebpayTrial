<?php
require_once('libwebpay/webpay.php'); //Libreria webpay :P
require_once('cert-normal.php'); //Contiene la variable $certificate con las credenciales que necesitamos
$error = FALSE;

//Configurancion y credenciales para Webpay
$configuration = new Configuration();
$configuration->setEnvironment($certificate['environment']);
$configuration->setCommerceCode($certificate['commerce_code']);
$configuration->setPrivateKey($certificate['private_key']);
$configuration->setPublicCert($certificate['public_cert']);
$configuration->setWebpayCert($certificate['webpay_cert']);

$webpay = new Webpay($configuration);

//Mi url
$baseurl = $_SERVER['REQUEST_SCHEME'] . "://" . $_SERVER['SERVER_NAME'];

//TODO validar entrada
if(isset($_POST["amount"])){
    $error = FALSE;
    $amount = $_POST["amount"];
}
else
{
    $error = TRUE;
}

$buyOrder = rand();
$sessionId = uniqid();
$urlReturn = $baseurl."/confirm.php";
$urlFinal = $baseurl."/end.php";

$result = $webpay->getNormalTransaction()->initTransaction($amount, $buyOrder, $sessionId, $urlReturn, $urlFinal);

/** Verificamos respuesta de inicio en webpay */
if (!empty($result->token) && isset($result->token)) {
    $message = "ok";
    $token = $result->token;
    $next_page = $result->url;
    
} else {
    $message = "error";
    $error = TRUE;
}

//Agregar vista de error
?>

<form action="<?php echo $next_page; ?>" method="post" name="myform" id="myform">
    <input type="hidden" name="token_ws" value="<?php echo ($token); ?>">
</form>

<script type="text/javascript">
    setTimeout(document.myform.submit(),10000);
</script>