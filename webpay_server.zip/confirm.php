<?php
require_once('libwebpay/webpay.php'); //Libreria webpay :P
require_once('cert-normal.php'); //Contiene la variable $certificate con las credenciales que necesitamos
$error = FALSE;

if(!isset($_POST["token_ws"]))
{
    $error = TRUE;
}

//Configurancion y credenciales para Webpay
$configuration = new Configuration();
$configuration->setEnvironment($certificate['environment']);
$configuration->setCommerceCode($certificate['commerce_code']);
$configuration->setPrivateKey($certificate['private_key']);
$configuration->setPublicCert($certificate['public_cert']);
$configuration->setWebpayCert($certificate['webpay_cert']);

$webpay = new Webpay($configuration);

//Obtener el resultado de la transaccion
//TODO validar input para que no me hagan ransomware D:

$token = $_POST["token_ws"];
$result = $webpay->getNormalTransaction()->getTransactionResult($token);
if ($result->detailOutput->responseCode !== 0)
{
    //Redireccionar a pagina de error
    $baseurl = $_SERVER['REQUEST_SCHEME'] . "://" . $_SERVER['SERVER_NAME'];
    header('Location: '.$baseurl.'/error.php');
    die();
}
else
{
    //Mostrar info de transaccion
    //Con boton continuar
    echo '<style>table {
        border: 1px solid #dddddd;
        margin-top: 20px;
        margin-bottom: 20px;
        margin-left: auto;
        margin-right: auto;
        }
        
        div {
        text-align: center
        }</style>';
    echo '<table><tr><th colspan="2">Pago realizado con éxito</th></tr><tr>';
    echo '<td>Código de comercio:</td><td>'.$result->detailOutput->commerceCode.'</td></tr><tr>';
    echo '<td>Código de autorización:</td><td>'.$result->detailOutput->authorizationCode.'</td></tr><tr>';
    echo '<td>Monto pagado:</td><td>'.$result->detailOutput->amount.'</td></tr><tr>';
    echo '<td>Orden de compra:</td><td>'.$result->detailOutput->buyOrder.'</td></tr></table>';
    
    echo '<div><form method="post" action="'.$result->urlRedirection.'" name="myform" id="myform">';
    echo '<input type="hidden" name="token_ws" value="'.$token.'">';
    echo '<input type="submit" name="submit" value="Continuar">';
    echo '</form></div>';
}

?>

<!--<form method="post" action="<?php //echo $result->urlRedirection;?>" name="myform" id="myform">
    <input type="hidden" name="token_ws" value="<?php //echo ($token); ?>">
</form>

<script type="text/javascript">
    setTimeout(document.myform.submit(),5000);
</script>-->